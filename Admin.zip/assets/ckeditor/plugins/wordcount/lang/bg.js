/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'bg', {
    WordCount: 'Думи:',
    WordCountRemaining: 'Оставащи думи',
    CharCount: 'Знаци:',
    CharCountRemaining: 'Знаци',
    CharCountWithHTML: 'Знаци (с HTML):',
    CharCountWithHTMLRemaining: 'Оставащи знаци (с HTML)',
    Paragraphs: 'Параграфи:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Съдържанието не може да бъде поставено, защото е над разрешения лимит',
    Selected: 'Избрани: ',
    title: 'Статистика'
});
