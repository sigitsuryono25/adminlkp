<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <meta name="robots" content="noindex, nofollow">
        <title>Default Image Plugin</title>
        <script src="<?php echo base_url() ?>assets/editor/ckeditor.js"></script>
    </head>

    <body>

        <!--        <form>
        
                    <textarea cols="80" id="editor1" name="editor1" rows="10" >&lt;p&gt;This is some &lt;strong&gt;sample text&lt;/strong&gt;. You are using &lt;a href="https://ckeditor.com/"&gt;CKEditor&lt;/a&gt;.&lt;/p&gt;
                    </textarea>
                </form>
                <script>
                    CKEDITOR.addCss('.cke_editable { font-size: 15px; padding: 2em; }');
        
                    var editor = CKEDITOR.replace('editor1', {
        
                        extraAllowedContent: 'h3{clear};h2{line-height};h2 h3{margin-left,margin-top}',
        
                        // Adding drag and drop image upload.
                        extraPlugins: 'print,format,font,colorbutton,justify,uploadimage',
                        uploadUrl: '<?php echo base_url('assets') ?>/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json',
        
                        // Configure your file manager integration. This example uses CKFinder 3 for PHP.
                        filebrowserBrowseUrl: '<?php echo base_url('assets') ?>/ckfinder/ckfinder.html',
                        filebrowserImageBrowseUrl: '<?php echo base_url('assets') ?>/ckfinder/ckfinder.html?type=Images',
                        filebrowserUploadUrl: '<?php echo base_url('assets') ?>/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                        filebrowserImageUploadUrl: '<?php echo base_url('assets') ?>/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
        
                        height: 560,
        
                        removeDialogTabs: 'image:advanced;link:advanced',
                        uploadUrl: '<?php echo base_url() ?>assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
                    });
        
                    CKFinder.setupCKEditor(editor);
                </script>-->
    </body>

</html>